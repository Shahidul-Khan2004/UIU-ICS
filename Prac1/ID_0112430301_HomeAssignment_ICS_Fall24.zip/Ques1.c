#include <stdio.h>

int main (void) {
    printf("Hello ICS Section K, 2024");
}