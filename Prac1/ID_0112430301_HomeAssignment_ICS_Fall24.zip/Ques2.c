#include <stdio.h>

int main (void) {
    printf("Programming is Fun\n");
    printf("I love programming\n");
}